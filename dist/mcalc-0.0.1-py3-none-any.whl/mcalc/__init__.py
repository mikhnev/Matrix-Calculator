name = "mcalc"
from mcalc import *
