from mcalc import main

main()